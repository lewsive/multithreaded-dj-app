CMAKE_HIP_STANDARD
------------------

.. versionadded:: 3.21

Default value for :prop_tgt:`HIP_STANDARD` target property if set when a target
is created.

See the :manual:`cmake-compile-features(7)` manual for information on
compile features and a list of supported compilers.

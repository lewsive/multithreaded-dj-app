CMAKE_DOTNET_SDK
----------------

.. versionadded:: 3.23

Default value for :prop_tgt:`DOTNET_SDK` property of targets.

This variable is used to initialize the :prop_tgt:`DOTNET_SDK`
property on all targets. See that target property for additional information.

CMAKE_HOST_LINUX
----------------

.. versionadded:: 3.25

Set to true when the host system is Linux.

CMAKE_ISPC_INSTRUCTION_SETS
---------------------------

.. versionadded:: 3.19

Default value for :prop_tgt:`ISPC_INSTRUCTION_SETS` property of targets.

This variable is used to initialize the :prop_tgt:`ISPC_INSTRUCTION_SETS` property
on all targets. See the target property for additional information.

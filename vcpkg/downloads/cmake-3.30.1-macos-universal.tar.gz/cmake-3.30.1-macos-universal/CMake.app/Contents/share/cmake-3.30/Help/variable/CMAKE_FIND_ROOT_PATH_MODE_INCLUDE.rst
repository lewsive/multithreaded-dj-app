CMAKE_FIND_ROOT_PATH_MODE_INCLUDE
---------------------------------

.. |FIND_XXX| replace:: :command:`find_file` and :command:`find_path`

.. include:: CMAKE_FIND_ROOT_PATH_MODE_XXX.txt

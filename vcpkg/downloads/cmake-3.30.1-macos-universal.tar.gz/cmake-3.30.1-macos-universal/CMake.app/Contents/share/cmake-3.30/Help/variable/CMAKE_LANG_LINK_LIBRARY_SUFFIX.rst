CMAKE_<LANG>_LINK_LIBRARY_SUFFIX
--------------------------------

.. versionadded:: 3.16

Language-specific suffix for libraries that you link to.

The suffix to use for the end of a library filename, ``.lib`` on Windows.

CMAKE_EXECUTABLE_SUFFIX_<LANG>
------------------------------

The suffix to use for the end of an executable filename of ``<LANG>``
compiler target architecture, if any.

It overrides :variable:`CMAKE_EXECUTABLE_SUFFIX` for language ``<LANG>``.

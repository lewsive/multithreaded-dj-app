CMAKE_EXPORT_FIND_PACKAGE_NAME
------------------------------

.. note::

  Experimental. Gated by ``CMAKE_EXPERIMENTAL_EXPORT_PACKAGE_DEPENDENCIES``.

Initializes the value of :prop_tgt:`EXPORT_FIND_PACKAGE_NAME`.

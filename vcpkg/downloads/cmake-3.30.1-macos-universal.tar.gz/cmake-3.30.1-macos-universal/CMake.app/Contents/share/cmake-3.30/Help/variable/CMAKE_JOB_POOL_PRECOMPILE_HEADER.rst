CMAKE_JOB_POOL_PRECOMPILE_HEADER
--------------------------------

.. versionadded:: 3.17

This variable is used to initialize the :prop_tgt:`JOB_POOL_PRECOMPILE_HEADER`
property on all the targets. See :prop_tgt:`JOB_POOL_PRECOMPILE_HEADER`
for additional information.
